
positivo = 0

for i in range(1, 5 + 1):
    numero = int(input('ingrese un numero: '))

    if numero > 0:
        positivo = positivo + 1

print(f'los numeros positivos son {positivo}')



