multiplo=[]

for i in range(1,31):
    if i % 3 ==0:
        multiplo.append(i)

print(multiplo)