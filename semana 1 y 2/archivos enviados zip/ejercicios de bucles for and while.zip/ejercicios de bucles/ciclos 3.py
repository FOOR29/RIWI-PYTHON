numero = int(input('ingresa un número: '))

for i in range(1, 11):
    print(f'{numero} x {i} = {numero * i}')