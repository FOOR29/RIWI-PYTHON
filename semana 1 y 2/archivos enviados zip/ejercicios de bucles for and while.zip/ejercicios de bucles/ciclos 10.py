inicio = int(input('ingresa un número: '))

for i in range (inicio, -1, -1):
    print(i)

    