while True:
    edad = int(input('Ingresa una edad: '))
    
    if edad >= 18:
        print('listo, eres mayor de edad')
        break