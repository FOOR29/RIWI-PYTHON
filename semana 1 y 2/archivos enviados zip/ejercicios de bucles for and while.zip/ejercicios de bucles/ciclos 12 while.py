multiplo=[]

contador=0

while contador <=30:

    if contador %3 == 0:
        multiplo.append(contador)
    
    contador+=1
print(multiplo)